//style imports
import * as Style from './nft.style';

const Nft = () => {
	return <Style.Container>nft</Style.Container>;
};

export default Nft;
