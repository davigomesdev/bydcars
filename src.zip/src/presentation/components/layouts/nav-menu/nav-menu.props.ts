export interface NavMenuProps {
	to: string;
	name: string;
}
