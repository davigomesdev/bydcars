import type React from 'react';

export interface LayoutProps {
	children: React.JSX.Element;
}
