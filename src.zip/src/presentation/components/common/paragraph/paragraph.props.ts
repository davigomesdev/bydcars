export interface ParagraphProps {
  text: string;
  color?: string;
  fontSize?: string;
  textAlign?: string;
  limit?: number;
}
