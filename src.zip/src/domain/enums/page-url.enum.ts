export enum PageUrlEnum {
  DEFAULT = '*',
  HOME = '',
  BUY = '/buy',
}
