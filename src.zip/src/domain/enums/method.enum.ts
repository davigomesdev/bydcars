export enum MethodEnum {
  GET = 'GET',
  DELETE = 'DELETE',
  POST = 'POST',
  PATCH = 'PATCH',
  PUT = 'PUT',
}
