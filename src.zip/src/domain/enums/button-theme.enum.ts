export enum ButtonThemeEnum {
  DEFAULT = 'default',
  THEME = 'theme',
  OUTLINE = 'outline',
}
