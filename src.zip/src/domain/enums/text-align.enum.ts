export enum TextAlignEnum {
  CENTER = 'center',
  LEFT = 'left',
  RIGHT = 'right',
  JUSTIFY = 'justify',
}
