export enum InputConversionTypeEnum {
  FROM = 'from',
  TO = 'to',
}
